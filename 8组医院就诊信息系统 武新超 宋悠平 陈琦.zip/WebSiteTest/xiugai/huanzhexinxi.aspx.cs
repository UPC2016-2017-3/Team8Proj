﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection conn = new SqlConnection(ConnStr);
        conn.Open();
        string str1 = "insert into huanzhe(姓名,pw,身份证号) values(' ',' ',' ')";
        SqlCommand com = new SqlCommand(str1, conn);
        com.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("huanzhexinxi.aspx");
        
    }
   
}