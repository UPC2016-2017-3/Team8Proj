﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
    
            Session["name"] = this.TextBox1.Text;
            Response.Redirect("/WebSiteTest/xinxichaxun.aspx");

    }
    

    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "")
            Response.Write("<script>alert('缺少必要信息！')</script>");
        else
        {
            string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection mycon2 = new SqlConnection(sqlstr);
            mycon2.Open();
            string sql = "insert into zhenduan(id,诊断,开药) values('" + TextBox2.Text.Trim() + "','" + TextBox3.Text.Trim() + "','" + TextBox4.Text.Trim() + "')";
            SqlCommand mycmd = new SqlCommand(sql, mycon2);
            mycmd.ExecuteNonQuery();
            Response.Write("<script>alert('提交成功！')</script>");
            mycon2.Close();
        }
    }
}