﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (this.TextBox1.Text == "" || this.TextBox2.Text == "" || this.TextBox3.Text == "")
        {
            Response.Write("<script>alert('所填信息不能为空')</script>");
        }
        else
        {
            string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("select * from huanzhe where 身份证号 ='" + this.TextBox3.Text + "'", conn);
            SqlDataReader sdr = cmd1.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
                Response.Write("<script>alert('该身份证被已注册，如非本人操作请联系管理员')</script>");
            else
            {
                sdr.Close();
                string str1 = "insert into huanzhe(姓名,pw,身份证号) values('" + this.TextBox1.Text + "','" + this.TextBox2.Text + "','" + this.TextBox3.Text + "')";
                SqlCommand com2 = new SqlCommand(str1, conn);
                com2.ExecuteNonQuery();
                SqlCommand cmd3 = new SqlCommand("Select id from huanzhe where 身份证号 ='" + this.TextBox3.Text + "'", conn);
                SqlDataReader dr = cmd3.ExecuteReader();
                if (dr.Read())
                {
                    this.Label4.Text = "注册成功，请记住你的用户名"+dr["id"].ToString();
                }
                dr.Close();
             
               
                conn.Close();
            }
        }
    }


    
   
    protected void Button2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}