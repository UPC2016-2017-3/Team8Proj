﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection conn = new SqlConnection(ConnStr);
        conn.Open();
        string id = Session["id"].ToString();
        SqlCommand cmd0 = new SqlCommand("Select 所挂日期 from shenqingguahao where id ='"+id+"'", conn);
        SqlDataReader dr = cmd0.ExecuteReader();
        if (dr.Read())
        {
            
            string dt = dr["所挂日期"].ToString();
            dr.Close();
            string yishengid = Session["yishengid"].ToString();
            SqlCommand cmd1 = new SqlCommand("update " + dt + " set 可挂号量=可挂号量+1 where 医生ID=" + yishengid + "", conn);
            cmd1.ExecuteNonQuery();
            
          
        }
        dr.Close();
        SqlCommand cmd = new SqlCommand("delete from shenqingguahao where id ='" + id + "'", conn);
        cmd.ExecuteNonQuery();
        conn.Close();
        Response.Write("<script>alert('取消挂号成功')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("guahaochaxun.aspx");
    }
}