﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class zhibanbiao : System.Web.UI.Page
{

    /// <summary> 
    /// 快速验证一个字符串是否符合指定的正则表达式。 
    /// </summary> 
    /// <param name="_express">正则表达式的内容。</param> 
    /// <param name="_value">需验证的字符串。</param> 
    /// <returns>是否合法的bool值。</returns> 
    public static bool QuickValidate(string _express, string _value)
    {
        if (_value == null) return false;
        System.Text.RegularExpressions.Regex myRegex = new System.Text.RegularExpressions.Regex(_express);
        if (_value.Length == 0)
        {
            return false;
        }
        return myRegex.IsMatch(_value);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }


    protected void Button1_Click(object sender, EventArgs e)

    {
       
           string express = "^(?<year>\\d{2,4})/(?<month>\\d{2})/(?<day>\\d{2})$";
        string value = TextBox1.Text;
        string x = QuickValidate(express, value).ToString();
        if (x =="False")
        {
            Response.Write("<script>alert('请按照正确格式输入日期')</script>");
            TextBox1.Text = "";
        }
        if(x=="True")
        {
            string t1 = "[" + TextBox1.Text + "]";
            string t2 =TextBox1.Text;
            DateTime dt1 = DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));
            DateTime dt2 = DateTime.Parse(t2);
            DateTime dt3 = DateTime.Parse(DateTime.Now.AddDays(3).ToString("yyyy/MM/dd"));
            int num1=DateTime.Compare(dt1, dt2);//方法获取一个数字,结果之小于0,则t1<t2, 大于0, 则t1> t2, 等于0, 则t1 = t2
            int num2 = DateTime.Compare(dt2, dt3);
            if (num1 >= 0)
            {
                string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
                SqlConnection mycon = new SqlConnection(sqlstr);
                mycon.Open();
                string sql1 = "select * from " + t1 + "where 值班id>14";
                SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
                try
                {
                    SqlDataAdapter pDa = new SqlDataAdapter(sql1, mycon);
                    DataSet myDs1 = new DataSet();
                    pDa.Fill(myDs1, "zhiban1");
                    GridView1.DataSource = myDs1;
                    GridView1.DataBind();
                }
                catch
                {
                    Response.Write("<script>alert('不存在该天值班表!')</script>");
                    TextBox1.Text = "";

                }
                mycon.Close();
            }
            else if (num1 < 0 && num2 < 0)
            {
                string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
                SqlConnection mycon = new SqlConnection(sqlstr);
                mycon.Open();
                string sql1 = "select * from " + t1 + "where 值班id>14";
                SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
                SqlDataAdapter pDa = new SqlDataAdapter(sql1, mycon);
                DataSet myDs2 = new DataSet();
                pDa.Fill(myDs2, "zhiban2");
                GridView1.DataSource = myDs2;
                GridView1.DataBind();
                mycon.Close();
            }
            else
            {

                string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
                SqlConnection conn = new SqlConnection(ConnStr);
                conn.Open();
                string sql1 = "select * from " + t1 + "where 值班id>14";
                SqlCommand mycmd2 = new SqlCommand(sql1, conn);
                try
                {
                    SqlDataAdapter pDa = new SqlDataAdapter(sql1,conn);
                    DataSet myDs3 = new DataSet();
                    pDa.Fill(myDs3, "zhiban3");
                    GridView1.DataSource = myDs3;
                    GridView1.DataBind();
                }
                catch
                {
                    string str1 = "CREATE TABLE " + t1 + "" + "(值班id int identity(1,1) not null  PRIMARY KEY," + "医生姓名 CHAR(50), 可挂号量 int, 时间段 char(10),医生id char(10),所属科室 char(10))";
                    SqlCommand cmd = new SqlCommand(str1, conn);
                    cmd.ExecuteNonQuery();
                    string str2 = "insert into " + t1 + "(医生id,医生姓名,可挂号量,时间段,所属科室) values(0,'医生0',0,'上午','科室1'),(0,'医生0',0,'上午','科室2'),(0,'医生0',0,'上午','科室3'),(0,'医生0',0,'上午','科室4'),(0,'医生0',0,'上午','科室5'),(0,'医生0',0,'上午','科室6'),(0,'医生0',0,'上午','科室7'),(0,'医生0',0,'下午','科室1'),(0,'医生0',0,'下午','科室2'),(0,'医生0',0,'下午','科室3'),(0,'医生0',0,'下午','科室4'),(0,'医生0',0,'下午','科室5'),(0,'医生0',0,'下午','科室6'),(0,'医生0',0,'下午','科室7')";
                    SqlCommand cmd3 = new SqlCommand(str2, conn);
                    cmd3.ExecuteNonQuery();
                    
                }
            }

        }
        string chaxun = "[" + TextBox1.Text + "]";
        string constr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection mycon1 = new SqlConnection(constr);
        mycon1.Open();
        string sql = "select * from "+chaxun+" where 值班id>14";
        SqlCommand cmd00 = new SqlCommand(sql, mycon1);
        SqlDataAdapter pDa0 = new SqlDataAdapter(sql, mycon1);
        DataSet myDs0 = new DataSet();
        pDa0.Fill(myDs0, "zhiban00");
        GridView1.DataSource = myDs0;      
        GridView1.DataBind();
        mycon1.Close();
        
    }

}