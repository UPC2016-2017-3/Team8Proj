﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string t = Session["name"].ToString();
        Label1.Text = t;
        string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection mycon = new SqlConnection(sqlstr);
        mycon.Open();
        string sql = "select * from zhenduan where id='"+t+"'";
        SqlCommand mycmd = new SqlCommand(sql, mycon);     
        SqlDataAdapter pDa = new SqlDataAdapter(sql, mycon);
        DataSet myDs = new DataSet();
        pDa.Fill(myDs, "zhenduan");
        GridView2.DataSource = myDs;
        GridView2.DataBind();

        
    }
    
}