﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class houtian : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string dt1 = "[" + DateTime.Now.AddDays(2).ToString("yyyy/MM/dd") + "]";
        string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection mycon = new SqlConnection(sqlstr);
        mycon.Open();
        string keshi = Session["keshi"].ToString();
        string sql1 = "select * from " + dt1 + "where 值班id>14 and 可挂号量>0 and 所属科室='" + keshi + "'and 时间段='上午'";
        SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
        SqlDataAdapter pDa = new SqlDataAdapter(sql1, mycon);
        DataSet myDs2 = new DataSet();
        pDa.Fill(myDs2, "zhiban2");
        GridView1.DataSource = myDs2;
        GridView1.DataBind();
        mycon.Close();

    }
    protected void btnDelOne_Click(object sender, EventArgs e)
    {

        string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection conn = new SqlConnection(ConnStr);
        conn.Open();
        Button btn = (Button)sender;

        string yishengid = btn.CommandArgument;//获取得到控件绑定的对应值
        int yishengid2 = Convert.ToInt32(yishengid);
        Session["yishengid"] = yishengid2;
        string dt1 = "[" + DateTime.Now.AddDays(2).ToString("yyyy/MM/dd") + "]";
        SqlCommand cmd = new SqlCommand("select 可挂号量 from " + dt1 + " where 医生ID=" + yishengid2 + "");
        cmd.Connection = conn;
        string shengyuguhaoshu = cmd.ExecuteScalar().ToString();
        int shengyuguhaoshu2 = Convert.ToInt32(shengyuguhaoshu);

        if (shengyuguhaoshu2 > 0)
        {

            string id = Session["id"].ToString();
            SqlCommand cmd3 = new SqlCommand("insert into shenqingguahao(id,医生id,所挂日期,时间) values('" + id + "','" + yishengid2 + "','" + dt1 + "','上午')", conn);
            cmd3.ExecuteNonQuery();
            SqlCommand cmd2 = new SqlCommand("update " + dt1 + " set 可挂号量=可挂号量-1 where 医生ID=" + yishengid2 + "", conn);
            cmd2.ExecuteNonQuery();
            Response.Redirect("/WebSiteTest/houtian.aspx");
            Response.Write("<script>alert('挂号成功')</script>");
        }

    }
}