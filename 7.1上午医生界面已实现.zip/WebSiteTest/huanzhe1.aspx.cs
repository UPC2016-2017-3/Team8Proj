﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Label2.Text = DateTime.Now.AddDays(1).ToString("MM/dd");
        Label3.Text = DateTime.Now.AddDays(2).ToString("MM/dd");
        Label4.Text = DateTime.Now.AddDays(3).ToString("MM/dd");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
    string dt1 = "[" + DateTime.Now.AddDays(1).ToString("yyyy/MM/dd") + "]";
            string dt2 = "[" + DateTime.Now.AddDays(2).ToString("yyyy/MM/dd") + "]";
            string dt3 = "[" + DateTime.Now.AddDays(3).ToString("yyyy/MM/dd") + "]";
            string sqlstr= "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection mycon = new SqlConnection(sqlstr);
            mycon.Open();
            string sql1 = "select sum(可挂号量)from "+dt1+" where 时间段 in('上午')and 所属科室='"+DropDownList1.Text+"'";
            SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
            SqlDataAdapter sum1 = new SqlDataAdapter(sql1, mycon);
            DataSet myDs = new DataSet();
            sum1.Fill(myDs,"num1");
            string s1=myDs.Tables["num1"].Rows[0].ItemArray[0].ToString();
            int num1 = Int32.Parse(s1);
            if (num1 > 0)
            {
                HyperLink1.Text = "剩余可挂号量：" + num1;
                HyperLink1.Visible = true;

            }
            else
                HyperLink1.Text = "约满";
            HyperLink1.Visible = true;
     
            mycon.Close();
        }
}
