﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    



    protected void Button1_Click(object sender, EventArgs e)
    {
        if (this.TextBox1.Text == "" || this.TextBox2.Text == "")
        {
            Response.Write("<script>alert('所填信息不能为空')</script>");
        }
        else
        {
            string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();
            int yanzheng = 0;
            string str1 = "select * from [huanzhe] where id='" + this.TextBox1.Text + "' and pw='" + this.TextBox2.Text + "'";
            string str2 = "select * from [yisheng] where 医生id='" + this.TextBox1.Text + "' and pw='" + this.TextBox2.Text + "' and 科室!='药房'";
            string str3 = "select * from [guanliyuan] where 管理员id='" + this.TextBox1.Text + "' and pw='" + this.TextBox2.Text + "'";
            string str4 = "select * from [yisheng] where 医生id='" + this.TextBox1.Text + "' and pw='" + this.TextBox2.Text + "' and 科室='药房'";

            SqlCommand com1 = new SqlCommand(str1, conn);
            SqlDataReader dr1 = com1.ExecuteReader();
            if (dr1.Read())
            {
                yanzheng = 1;
                Session["id"] = this.TextBox1.Text;
                Response.Redirect("huanzhe.aspx");

            }
            dr1.Close();


            SqlCommand com2 = new SqlCommand(str2, conn);
            SqlDataReader dr2 = com2.ExecuteReader();
            if (dr2.Read())
            {
                yanzheng = 2;
                Session["id"] = this.TextBox1.Text;
                Response.Redirect("yisheng.aspx");

            }
            dr2.Close();


            SqlCommand com3 = new SqlCommand(str3, conn);
            SqlDataReader dr3 = com3.ExecuteReader();
            if (dr3.Read())
            {
                yanzheng = 3;
                Session["id"] = this.TextBox1.Text;
                Response.Redirect("guanliyuan.aspx");
            }
            dr3.Close();

            SqlCommand com4 = new SqlCommand(str4, conn);
            SqlDataReader dr4 = com4.ExecuteReader();
            if (dr4.Read())
            {
                yanzheng = 4;
                Session["id"] = this.TextBox1.Text;
                Response.Redirect("yaofangyisheng.aspx");

            }
            dr4.Close();

           

            if (yanzheng == 0)
            {
                Response.Write("<script>alert('用户名或密码错误！')</script>");
            }
            conn.Close();
        }
       

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("zhuce.aspx");
    }
}
