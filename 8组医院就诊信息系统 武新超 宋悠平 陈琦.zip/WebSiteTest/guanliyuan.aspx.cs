﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
       Label3.Text = DateTime.Now.ToString();
       Label1.Text = Session["id"].ToString();
        string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        SqlConnection conn = new SqlConnection(ConnStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Select 权限 from guanliyuan where 管理员id ='" + this.Label1.Text + "'", conn);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            this.Label2.Text =dr["权限"].ToString();
        }
        dr.Close();
        conn.Close();
        

    }
   

    protected void Button1_Click(object sender, EventArgs e)
    {
        string t = Session["id"].ToString();

        if (t == "30001")
        {
           

             Response.Redirect("/WebSiteTest/xiugai/chujiguanli.aspx");

        }

        else
        {
            Response.Redirect("/WebSiteTest/wuquanxian.aspx");

        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {

    }
}
