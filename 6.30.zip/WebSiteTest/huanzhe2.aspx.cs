﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnDelOne_Click(object sender, EventArgs e)
    {

        
    
            string ConnStr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();
            Button btn = (Button)sender;

            string yishengid = btn.CommandArgument;//获取得到控件绑定的对应值
            int yishengid2 = Convert.ToInt32(yishengid);

            SqlCommand cmd = new SqlCommand("select 剩余挂号数 from shengyubiao1 where 医生id=" + yishengid2 + "");
            cmd.Connection = conn;
            string shengyuguhaoshu = cmd.ExecuteScalar().ToString();
            int shengyuguhaoshu2 = Convert.ToInt32(shengyuguhaoshu);

            if (shengyuguhaoshu2 > 0)
            {


                SqlCommand cmd2 = new SqlCommand("update shengyubiao1 set 剩余挂号数=剩余挂号数-1 where 医生id=" + yishengid2 + "", conn);
                cmd2.ExecuteNonQuery();
                Response.Write("<script>alert('挂号成功')</script>");
            }
            else {
                Response.Write("<script>alert('号已满')</script>");
            }
           
         

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("/WebSiteTest/Login.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("huanzhe.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}