﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label4.Text = DateTime.Now.ToString();
        Label3.Text = Session["id"].ToString();
    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        string dt1 = "[" + DateTime.Now.AddDays(0).ToString("yyyy/MM/dd") + "]";
        SqlConnection mycon = new SqlConnection(sqlstr);
        mycon.Open();
        
            string sql1 = "select 药方,是否取药 from  zhenduan where id='" + TextBox1.Text + "'and 诊断时间='"+dt1+"'";
            SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
            SqlDataReader dr = mycmd1.ExecuteReader();
            if (dr.Read())
            {
                this.Label1.Text = dr["是否取药"].ToString();
                this.Label2.Text = dr["药方"].ToString();

            }
            else
            {


                Response.Write("<script>alert('查询不到该患者药方')</script>");
                this.Label1.Text = "显示取药状态";
                this.Label2.Text = "显示药方";
            }

            dr.Close();
            mycon.Close();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
        string dt1 = "[" + DateTime.Now.AddDays(0).ToString("yyyy/MM/dd") + "]";
        SqlConnection mycon = new SqlConnection(sqlstr);
        mycon.Open();

        string sql1 = "update zhenduan set 是否取药='已取药' where id='" + TextBox1.Text + "'and 诊断时间='" + dt1 + "'";
        SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
        mycmd1.ExecuteNonQuery();
        mycon.Close();
        this.Label1.Text = "已取药";
    }
}