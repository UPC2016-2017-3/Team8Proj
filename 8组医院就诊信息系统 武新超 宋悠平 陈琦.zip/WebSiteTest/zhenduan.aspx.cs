﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        TextBox4.Text = TextBox4.Text+DropDownList1.Text+TextBox3.Text+";";
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" )
            Response.Write("<script>alert('缺少必要信息！')</script>");
        else
        {
            string dt1 = "[" + DateTime.Now.ToString("yyyy/MM/dd") + "]";
            string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection mycon2 = new SqlConnection(sqlstr);
            mycon2.Open();
            string sql = "insert into zhenduan(id,诊断,诊断时间,药方) values('" + TextBox1.Text.Trim() + "','" + TextBox2.Text.Trim() + "','" + dt1 + "','" + TextBox4.Text.Trim() + "')";
            SqlCommand mycmd = new SqlCommand(sql, mycon2);
            mycmd.ExecuteNonQuery();
            Response.Write("<script>alert('提交药方成功！')</script>");
            mycon2.Close();
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("zhenduan.aspx");
    }
}
