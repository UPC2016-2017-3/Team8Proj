﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;

public partial class huanzhe1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Label2.Text = DateTime.Now.AddDays(1).ToString("MM/dd");
        Label3.Text = DateTime.Now.AddDays(2).ToString("MM/dd");
        Label4.Text = DateTime.Now.AddDays(3).ToString("MM/dd");
        
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
            Session["keshi"] = DropDownList1.Text.ToString();
            string dt1 = "[" + DateTime.Now.AddDays(1).ToString("yyyy/MM/dd") + "]";
            string dt2 = "[" + DateTime.Now.AddDays(2).ToString("yyyy/MM/dd") + "]";
            string dt3 = "[" + DateTime.Now.AddDays(3).ToString("yyyy/MM/dd") + "]";
            string sqlstr = "Data Source=DESKTOP-69J6QRJ;Initial Catalog=users;Integrated Security=True";
            SqlConnection mycon = new SqlConnection(sqlstr);
            mycon.Open();
            string sql1 = "select sum(可挂号量)from "+dt1+" where 时间段 in('上午')and 所属科室='"+DropDownList1.Text+"'";
            SqlCommand mycmd1 = new SqlCommand(sql1, mycon);
            SqlDataAdapter sum1 = new SqlDataAdapter(sql1, mycon);
            DataSet myDs = new DataSet();
            sum1.Fill(myDs,"num1");
            string s1=myDs.Tables["num1"].Rows[0].ItemArray[0].ToString();
            int num1 = Int32.Parse(s1);
        if (num1 > 0)
        {
            HyperLink1.Text = "剩余可挂号量：" + num1;
            HyperLink1.Visible = true;
            Label13.Visible = false;

        }
        else
        {
            HyperLink1.Visible = false;
            Label13.Visible = true;
            Label13.Text = "约满";

        }
        string sql2 = "select sum(可挂号量)from " + dt1 + " where 时间段 in('下午')and 所属科室='" + DropDownList1.Text + "'";
        SqlCommand mycmd2 = new SqlCommand(sql2, mycon);
        SqlDataAdapter sum2 = new SqlDataAdapter(sql2, mycon);
        sum2.Fill(myDs, "num2");
        string s2 = myDs.Tables["num2"].Rows[0].ItemArray[0].ToString();
        int num2 = Int32.Parse(s2);
        if (num2 > 0)
        {
            HyperLink4.Text = "剩余可挂号量：" + num2;
            HyperLink4.Visible = true;
            Label16.Visible = false;
        }
        else
        {
            HyperLink4.Visible = false;
            Label16.Visible = true;
            Label16.Text = "约满";

        }

        string sql3 = "select sum(可挂号量)from " + dt2 + " where 时间段 in('上午')and 所属科室='" + DropDownList1.Text + "'";
        SqlCommand mycmd3 = new SqlCommand(sql3, mycon);
        SqlDataAdapter sum3 = new SqlDataAdapter(sql3, mycon);

        sum3.Fill(myDs, "num3");
        string s3 = myDs.Tables["num3"].Rows[0].ItemArray[0].ToString();
        int num3 = Int32.Parse(s3);
        if (num3 > 0)
        {
            HyperLink2.Text = "剩余可挂号量：" + num3;
            HyperLink2.Visible = true;
            Label14.Visible = false;
        }
        else
        {
            HyperLink2.Visible = false;
            Label14.Visible = true;
            Label14.Text = "约满";

        }

        string sql4 = "select sum(可挂号量)from " + dt2 + " where 时间段 in('下午')and 所属科室='" + DropDownList1.Text + "'";
        SqlCommand mycmd4 = new SqlCommand(sql4, mycon);
        SqlDataAdapter sum4 = new SqlDataAdapter(sql4, mycon);
        sum4.Fill(myDs, "num4");
        string s4 = myDs.Tables["num4"].Rows[0].ItemArray[0].ToString();
        int num4 = Int32.Parse(s4);
        if (num4 > 0)
        {
            h5.Text = "剩余可挂号量：" + num4;
            h5.Visible = true;
            Label17.Visible = false;
        }
        else
        {
            h5.Visible = false;
            Label17.Visible = true;
            Label17.Text = "约满";

        }

        string sql5 = "select sum(可挂号量)from " + dt3 + " where 时间段 in('上午')and 所属科室='" + DropDownList1.Text + "'";
        SqlCommand mycmd5 = new SqlCommand(sql5, mycon);
        SqlDataAdapter sum5 = new SqlDataAdapter(sql5, mycon);
        sum5.Fill(myDs, "num5");
        string s5 = myDs.Tables["num5"].Rows[0].ItemArray[0].ToString();
        int num5 = Int32.Parse(s5);
        if (num5 > 0)
        {
            HyperLink3.Text = "剩余可挂号量：" + num5;
            HyperLink3.Visible = true;
            Label15.Visible = false;
        }
        else
        {
            HyperLink3.Visible = false;
            Label15.Visible = true;
            Label15.Text = "约满";

        }

        string sql6 = "select sum(可挂号量)from " + dt3 + " where 时间段 in('下午')and 所属科室='" + DropDownList1.Text + "'";
        SqlCommand mycmd6 = new SqlCommand(sql6, mycon);
        SqlDataAdapter sum6 = new SqlDataAdapter(sql6, mycon);
        sum6.Fill(myDs, "num6");
        string s6 = myDs.Tables["num6"].Rows[0].ItemArray[0].ToString();
        int num6 = Int32.Parse(s6);
        if (num6 > 0)
        {
            h6.Text = "剩余可挂号量：" + num6;
            h6.Visible = true;
            Label18.Visible = false;
        }
        else
        {
            h6.Visible = false;
            Label18.Visible = true;
            Label18.Text = "约满";

        }
        mycon.Close();
        }
}
